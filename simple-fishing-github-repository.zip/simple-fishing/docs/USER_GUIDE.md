# Simple Fishing 1.5.0

Fishing actor tokens, a d20 bite roll, and a moving-fish catch game for D&D 5e on Foundry VTT 14. No extra modules required.

## Install or update

1. Close Foundry.
2. Extract the ZIP and put the **simple-fishing** folder in **Data/modules/**, replacing the old folder when updating.
3. Confirm the manifest is at **Data/modules/simple-fishing/module.json**.
4. Restart Foundry and enable **Simple Fishing** in Manage Modules.
5. **Every player must refresh their browser page.** Use Ctrl+Shift+R to clear cached module code.

GitHub releases include a generated module.json manifest URL for Foundry installation and updates. See the repository README for publishing instructions. If you downloaded the release asset simple-fishing.zip for a manual install, create Data/modules/simple-fishing and extract that ZIP into it.

## Change difficulty without rebuilding

Open **Configure Settings → Module Settings → Simple Fishing → Fishing Difficulty**.

Expand a section, change the values, and click **Save difficulty**. Changes persist for the world and apply when the next bite roll starts. An ongoing catch game keeps its original settings. No source editing, rebuilding, or restart is required for future difficulty adjustments.

**Restore defaults** resets the form. Click **Save difficulty** to apply those defaults. Rewards and existing spot counts are not reset.

| Section | Controls | Defaults |
|---|---|---|
| Catch bar and movement | Easy zone size / sweep time | 30% / 2.4 seconds |
| Catch bar and movement | Medium zone size / sweep time | 15% / 1.8 seconds |
| Catch bar and movement | Hard zone size / sweep time | 6% / 1.3 seconds |
| Bait and abilities | No-bait bite DC penalty | +5 |
| Bait and abilities | No-bait zone reduction | 35% |
| Bait and abilities | Sweep duration bonus per DEX modifier | 10% |
| Bait and abilities | Zone size bonus per WIS modifier | 5% relative to base width |
| Bite rolls and criticals | Bite DC adjustment for every spot | 0 |
| Bite rolls and criticals | Catches lost on failed bite roll | 1 |
| Bite rolls and criticals | Extra catches on natural 20 | 1 |
| Bite rolls and criticals | Natural 1 scares fish away and deletes spot | Enabled |
| Timers and equipment | Catch-game time limit | 15 seconds |
| Timers and equipment | GM approval timeout | 180 seconds |
| Timers and equipment | Require Fishing Tackle | Enabled |
| New spots | Default catch count / bite DC | 6 / 10 |
| Advanced limits | Minimum / maximum final green zone | 2.5% / 50% |
| Advanced limits | Minimum / maximum DEX sweep multiplier | 50% / 200% |
| Advanced limits | Minimum / maximum WIS zone multiplier | 50% / 150% |

Larger zones are easier. Longer sweep times mean slower fish. A sweep is one full back-and-forth trip. Set a stat bonus, bait penalty, catch loss, or critical bonus to **0** to turn that effect off. Final bite DC is capped between 1 and 20. Invalid values and reversed minimum/maximum limits cannot be saved.

## Add rewards

Open **Module Settings → Simple Fishing → Fishing Rewards**.

Drag your own **Items or RollTables** from a sidebar or compendium into Common, Uncommon, or Rare. A list shows what has been added; × removes an entry. Drops and removals save automatically. There are no built-in reward tables or per-spot reward overrides.

One entry is chosen randomly per attempt. An Item entry awards one copy with quantity 1 on success. A RollTable entry rolls that table recursively and awards its Item results. Multiple returned Items count as one successful catch. Text-only results produce a result message, not an inventory item. No rewards are awarded on bite failure or a failed Reel.

Tables use Foundry's recursive `roll()`, not `draw()`, so fishing does not mark results drawn. Spot counts manage supply. Reset any previously drawn table entries and enable replacement for repeatable rewards. An empty reward list blocks the cast before spending bait.

## Place and edit spots

1. Open **Token Controls**, the character/token icon on the left toolbar.
2. Click the **fish button — Add Fishing Spot**.
3. Click the map. Escape cancels placement.
4. Set name, catches remaining, difficulty, bite DC, and Delete spot when empty in the small fishing-only setup window. Click Save.

The reusable **Fishing Spot** NPC actor is created automatically. You can also drag that actor from the Actors sidebar; the fishing setup opens for the new token. New-spot defaults follow Fishing Difficulty settings. Existing spots retain their counts and base bite DC; the global bite adjustment affects them.

GM double-click opens the fishing-only setup. Players single-click the spot to fish. Move/delete a spot with normal token tools or use Delete spot in its setup. Each placed token has its own stock; the actor stays available after a token is deleted.

Old fishing tiles are converted into actor tokens when the primary GM opens their scene. Conversion preserves spot settings and removes the old tile after a token exists. Other tiles are untouched.

## Players: cast, bite, reel

Choose an owned character and bait, or **No bait**. By default that character must have a positive-quantity **Fishing Tackle** item. The standard name or D&D identifier `fishing-tackle` is recognized, including renamed items retaining that identifier. Tackle is reusable, does not need to be equipped, and is excluded from bait choices. The DM can disable the requirement in Fishing Difficulty.

Click Cast. The GM client prepares the reward, uses one selected bait item, and rolls **1d20**. Quantity-one bait is removed; a stack decreases by one. No bait consumes no inventory item. The result is whispered to the player and processing GM.

With default rules:

- No bait adds **+5** to the spot's bite DC and narrows the eventual green zone by 35%.
- A failed bite roll removes **1 remaining catch**. Delete when empty applies if the count reaches zero.
- A natural 1 says **“The fish were scared away!”** and deletes the placed spot even if Delete when empty is off.
- A natural 20 adds **1 remaining catch** and opens the catch game. A successful Reel then uses one catch, leaving the spot at its count before the bonus. A missed Reel retains the bonus.
- Other successful bite rolls open the catch game.

When the game opens, click Reel once while the fish's center is in the green zone. The default time limit is 15 seconds. Success adds Item rewards to inventory and spends one catch. A missed Reel awards nothing and does not reduce stock further. The result appears in the same window, with another Cast option if the spot is still available.

All listed penalties, bonuses, timings, and tackle/critical requirements are configurable in Fishing Difficulty.

## Character effects

The GM reads the selected character's prepared Dexterity and Wisdom modifiers for each attempt; ability scores are a fallback. The stats affect the minigame, not the d20 bite roll.

With default settings, each DEX modifier point lengthens the full sweep by 10%. Each WIS modifier point adds 5% of the difficulty's base zone width. WIS +5 turns a hard 6% zone into **7.5%**, rather than adding 10 percentage points. Negative modifiers have the opposite effect, within the configured limits.

The no-bait zone reduction applies after Wisdom. Final width and speed multipliers obey the advanced minimum/maximum settings. Set DEX/WIS bonuses to 0 to disable stat effects.

## Optional GM choice for unusual bait

Enable **GM chooses each catch** in Fishing Rewards. The player waits in the same window while the GM sees the bait and chooses difficulty and catch. Type a custom loot-item name or drag an Item into the Catch field. Leave it blank to use the appropriate reward list.

Click Roll for a bite. Cancelling before this roll keeps the bait. Custom catches still require a successful bite roll and Reel to be awarded.

## Limits and recovery

- An active GM is required. With multiple GMs, only the primary active GM processes casts.
- One active attempt per spot and one per character. Stock and inventory updates run on the GM client.
- Players need permission to create chat messages; requests use private GM whispers.
- Fishing spots should not overlap character tokens. A visible spot on the current scene can be used; no proximity rule is enforced.
- Closing the player window cancels the attempt. Bait already spent is not refunded.
- Finish attempts before refreshing or switching the primary GM. Sessions are in memory; the GM should restore bait manually after an interrupted attempt.
- Avoid changing stock or inventory during an attempt. A missing or empty spot cannot award a catch.
- Started attempts have the configured game duration plus 30 seconds of network-delivery grace on the GM side.
- This is a casual minigame, not an anti-cheat system. English labels only.

## Developer API and validation

```js
game.modules.get("simple-fishing").api.placeSpot();
game.modules.get("simple-fishing").api.settings(); // rewards
game.modules.get("simple-fishing").api.difficulty();
```

Run `node --test dev-tests/fishing.test.mjs` with Node 22+ from this folder.

Syntax and mocked integration tests cover saving/restoring difficulty settings, custom timers/zone sizes, zeroed bonuses, stat limits, no-bait bite penalties, configured failed-roll/critical rules, optional/required tackle, native and overlay token clicks, old-tile migration, inventory rewards, ownership checks, duplicate attempts, depletion and rollback. The mock includes Foundry's read-only ApplicationV2 state getter to prevent the former window-construction error from returning.

This build targets Foundry VTT 14's documented APIs. It has not been run inside a licensed Foundry instance or tested with real multiplayer clients. The manifest permits later major versions, but compatibility with them is not guaranteed.

API references:

- https://foundryvtt.com/api/v14/classes/foundry.applications.api.ApplicationV2.html
- https://foundryvtt.com/api/v14/functions/hookEvents.getSceneControlButtons.html
- https://foundryvtt.com/api/v14/classes/foundry.dice.Roll.html
