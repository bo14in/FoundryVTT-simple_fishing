Fishing spots for D&D 5e on Foundry VTT 14:

- Clickable Fishing Spot actor tokens with a button under Token Controls.
- D20 bite rolls followed by a moving-fish timing game.
- Fishing Tackle requirement, inventory bait, and a no-bait penalty.
- Character Dexterity and Wisdom effects on fish speed and catch-zone size.
- Drag-and-drop reward lists using Items and RollTables, with inventory rewards.
- Shared spot stock, failed-roll depletion, and configurable natural 1/20 outcomes.
- GM difficulty settings for bar sizes, speeds, stat bonuses, timers and penalties.

Initial release build. Automated checks cover mocked Foundry behavior and packaging; live multiplayer validation is still needed.

Install using the module.json release asset's URL. For manual installation, create Data/modules/simple-fishing and extract simple-fishing.zip into that folder.
