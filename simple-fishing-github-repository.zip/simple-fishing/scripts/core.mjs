export const ID = "simple-fishing";
export const TIERS = ["common", "uncommon", "rare"];
export function positionAt(elapsed, period, phase = 0) {
  const t = ((elapsed / period + phase) % 1 + 1) % 1;
  return t < 0.5 ? t * 2 : 2 - t * 2;
}
export function caught(elapsed, game) {
  if (!Number.isFinite(elapsed) || elapsed < 0 || elapsed > (game.duration ?? 15000)) return false;
  const p = positionAt(elapsed, game.period, game.phase);
  return p >= game.zone && p <= game.zone + game.width;
}
export function spotData(data = {}) {
  return {
    enabled: true, name: String(data.name || "Fishing Spot").slice(0,100),
    remaining: Math.max(0, Math.floor(Number(data.remaining) || 0)),
    tier: TIERS.includes(data.tier) ? data.tier : "common",
    biteDC: Math.max(1,Math.min(20,Math.floor(Number(data.biteDC) || 10))),
    deleteEmpty: !!data.deleteEmpty
  };
}
export function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
export function plainText(text) {
  return String(text || "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

export function abilityModifier(actor,key){
  const ability=actor?.system?.abilities?.[key];
  if(ability?.mod!==undefined && ability.mod!==null && Number.isFinite(Number(ability.mod))) return Number(ability.mod);
  const score=Number(ability?.value ?? 10);
  return Number.isFinite(score) ? Math.floor((score-10)/2) : 0;
}
export function isFishingTackle(item){
  const normalize=value=>String(value ?? "").toLowerCase().replace(/[^a-z0-9]/g,"");
  return normalize(item?.system?.identifier)==="fishingtackle" || /^fishing[\s-]+tackle(?:\b|$)/i.test(String(item?.name ?? "").trim());
}
export function hasFishingTackle(actor){
  return [...(actor?.items?.values() ?? [])].some(item=>isFishingTackle(item) && Number(item.system?.quantity ?? 1)>0);
}
export const BALANCE_FIELDS = [
  ["commonWidth","Easy green-zone size (%)",30,1,95,0.5,"Catch bar and movement"],
  ["commonSeconds","Easy fish sweep (seconds)",2.4,0.2,20,0.1,"Catch bar and movement"],
  ["uncommonWidth","Medium green-zone size (%)",15,1,95,0.5,"Catch bar and movement"],
  ["uncommonSeconds","Medium fish sweep (seconds)",1.8,0.2,20,0.1,"Catch bar and movement"],
  ["rareWidth","Hard green-zone size (%)",6,1,95,0.5,"Catch bar and movement"],
  ["rareSeconds","Hard fish sweep (seconds)",1.3,0.2,20,0.1,"Catch bar and movement"],
  ["noBaitPenalty","No-bait bite DC penalty",5,0,20,1,"Bait and abilities"],
  ["noBaitReduction","No-bait green-zone reduction (%)",35,0,95,1,"Bait and abilities"],
  ["dexBonus","Sweep duration bonus per DEX modifier (%)",10,0,100,1,"Bait and abilities"],
  ["wisBonus","Zone size bonus per WIS modifier (%)",5,0,100,1,"Bait and abilities"],
  ["globalBiteAdjustment","Bite DC adjustment for all spots",0,-20,20,1,"Bite rolls and criticals"],
  ["failedBiteLoss","Catches lost on failed bite roll",1,0,99,1,"Bite rolls and criticals"],
  ["naturalTwentyBonus","Extra catches on natural 20",1,0,99,1,"Bite rolls and criticals"],
  ["naturalOneScares","Natural 1 scares fish away and deletes spot",true,null,null,null,"Bite rolls and criticals"],
  ["durationSeconds","Catch-game time limit (seconds)",15,1,120,1,"Timers and equipment"],
  ["approvalSeconds","GM approval timeout (seconds)",180,15,1800,1,"Timers and equipment"],
  ["tackleRequired","Require Fishing Tackle",true,null,null,null,"Timers and equipment"],
  ["defaultStock","Default catches for new spots",6,1,99999,1,"New spots"],
  ["defaultBiteDC","Default bite DC for new spots",10,1,20,1,"New spots"],
  ["zoneMinimum","Minimum final green-zone size (%)",2.5,0.5,95,0.5,"Advanced limits"],
  ["zoneMaximum","Maximum final green-zone size (%)",50,0.5,95,0.5,"Advanced limits"],
  ["dexMinimum","Minimum DEX sweep multiplier (%)",50,10,500,1,"Advanced limits"],
  ["dexMaximum","Maximum DEX sweep multiplier (%)",200,10,500,1,"Advanced limits"],
  ["wisMinimum","Minimum WIS zone multiplier (%)",50,10,500,1,"Advanced limits"],
  ["wisMaximum","Maximum WIS zone multiplier (%)",150,10,500,1,"Advanced limits"]
];
export const DEFAULT_BALANCE=Object.freeze(Object.fromEntries(BALANCE_FIELDS.map(([key,,value])=>[key,value])));
export function normalizeBalance(input={}){
  const out={};
  for(const [key,,fallback,min,max] of BALANCE_FIELDS){
    if(typeof fallback==="boolean") out[key]=typeof input[key]==="boolean" ? input[key] : fallback;
    else {const value=input[key]===undefined || input[key]===null || input[key]==="" ? fallback : Number(input[key]);out[key]=Number.isFinite(value) ? Math.max(min,Math.min(max,value)) : fallback;}
  }
  for(const [low,high] of [["zoneMinimum","zoneMaximum"],["dexMinimum","dexMaximum"],["wisMinimum","wisMaximum"]]) if(out[low]>out[high]) [out[low],out[high]]=[out[high],out[low]];
  return out;
}
export function validateBalance(input){
  for(const [key,label,fallback,min,max,step] of BALANCE_FIELDS){
    if(typeof fallback==="boolean"){if(typeof input[key]!=="boolean") throw Error(`${label} must be enabled or disabled.`);}
    else if(input[key]==="" || !Number.isFinite(Number(input[key])) || Number(input[key])<min || Number(input[key])>max || (step===1 && !Number.isInteger(Number(input[key])))) throw Error(`${label} must be ${step===1 ? "a whole number" : "a number"} from ${min} to ${max}.`);
  }
  for(const [low,high] of [["zoneMinimum","zoneMaximum"],["dexMinimum","dexMaximum"],["wisMinimum","wisMaximum"]]) if(Number(input[low])>Number(input[high])) throw Error("Each minimum limit must be no greater than its maximum.");
  return normalizeBalance(input);
}
export function characterDifficulty(actor,tier,hasBait,input){
  const rules=normalizeBalance(input),key=TIERS.includes(tier) ? tier : "common";
  const dexMod=abilityModifier(actor,"dex"),wisMod=abilityModifier(actor,"wis");
  const wisdomFactor=Math.max(rules.wisMinimum/100,Math.min(rules.wisMaximum/100,1+wisMod*rules.wisBonus/100));
  const width=Math.max(rules.zoneMinimum/100,Math.min(rules.zoneMaximum/100,rules[`${key}Width`]/100*wisdomFactor*(hasBait ? 1 : 1-rules.noBaitReduction/100)));
  const period=Math.round(rules[`${key}Seconds`]*1000*Math.max(rules.dexMinimum/100,Math.min(rules.dexMaximum/100,1+dexMod*rules.dexBonus/100)));
  return {width,period,dexMod,wisMod,noBait:!hasBait,duration:rules.durationSeconds*1000};
}
export function biteDifficulty(spot,hasBait,input){
  const rules=normalizeBalance(input);
  return Math.max(1,Math.min(20,spotData(spot).biteDC+rules.globalBiteAdjustment+(hasBait ? 0 : rules.noBaitPenalty)));
}
