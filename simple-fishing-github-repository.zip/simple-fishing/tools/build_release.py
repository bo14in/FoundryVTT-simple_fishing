#!/usr/bin/env python3
"""Build a Foundry install package and release manifest without editing source."""
import argparse
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build(repository: str, tag: str, output: Path, root: Path = ROOT):
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repository):
        raise ValueError("Repository must be OWNER/REPOSITORY.")
    manifest = json.loads((root / "module.json").read_text())
    package = json.loads((root / "package.json").read_text())
    version = manifest["version"]
    if tag != f"v{version}":
        raise ValueError(f"Release tag must be v{version}; update module.json and package.json for a new version.")
    if package["version"] != version:
        raise ValueError("module.json and package.json versions must match.")
    if manifest["id"] != "simple-fishing":
        raise ValueError("The module ID must remain simple-fishing.")
    base = f"https://github.com/{repository}"
    manifest.update({
        "url": base,
        "manifest": f"{base}/releases/latest/download/module.json",
        "download": f"{base}/releases/download/{tag}/simple-fishing.zip",
        "bugs": f"{base}/issues",
    })
    encoded = (json.dumps(manifest, indent=2) + "\n").encode()
    output.mkdir(parents=True, exist_ok=True)
    manifest_path = output / "module.json"
    archive_path = output / "simple-fishing.zip"
    manifest_path.write_bytes(encoded)
    # Explicit runtime directories prevent uploading tests, workflow files, or secrets.
    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("module.json", encoded)
        archive.write(root / "LICENSE", "LICENSE")
        archive.write(root / "docs" / "USER_GUIDE.md", "README.md")
        for directory in ("scripts", "styles", "icons"):
            for path in sorted((root / directory).rglob("*")):
                if path.is_symlink():
                    raise ValueError(f"Refusing symlink: {path}")
                if path.is_file():
                    archive.write(path, path.relative_to(root).as_posix())
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip():
            raise ValueError("Release ZIP validation failed.")
        for path in manifest.get("esmodules", []) + manifest.get("styles", []):
            if path not in archive.namelist():
                raise ValueError(f"Missing runtime asset: {path}")
    return manifest_path, archive_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, help="GitHub OWNER/REPOSITORY")
    parser.add_argument("--tag", required=True, help="Release tag, e.g. v1.5.0")
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    args = parser.parse_args()
    try:
        paths = build(args.repository, args.tag, args.output)
    except (ValueError, OSError, KeyError) as error:
        parser.exit(1, f"Build failed: {error}\n")
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
