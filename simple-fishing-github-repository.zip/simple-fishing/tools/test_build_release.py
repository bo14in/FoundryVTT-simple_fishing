import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from build_release import ROOT, build


class ReleaseBuildTests(unittest.TestCase):
    def test_build_has_real_install_urls_and_runtime_only_zip(self):
        original = (ROOT / "module.json").read_bytes()
        version = json.loads(original)["version"]
        with tempfile.TemporaryDirectory() as directory:
            manifest_path, archive_path = build("example-owner/simple-fishing", f"v{version}", Path(directory))
            manifest = json.loads(manifest_path.read_text())
            self.assertEqual(manifest["manifest"], "https://github.com/example-owner/simple-fishing/releases/latest/download/module.json")
            self.assertEqual(manifest["download"], f"https://github.com/example-owner/simple-fishing/releases/download/v{version}/simple-fishing.zip")
            with zipfile.ZipFile(archive_path) as archive:
                self.assertEqual(archive.read("module.json"), manifest_path.read_bytes())
                self.assertIn("scripts/core.mjs", archive.namelist())
                self.assertIn("icons/spot.svg", archive.namelist())
                self.assertIn("README.md", archive.namelist())
                self.assertFalse(any(name.startswith((".git", "tools/", "dev-tests/")) for name in archive.namelist()))
        self.assertEqual((ROOT / "module.json").read_bytes(), original)

    def test_version_mismatch_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                build("example-owner/simple-fishing", "v0.0.0", Path(directory))

    def test_invalid_repository_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                build("../../outside", "v1.5.0", Path(directory))


if __name__ == "__main__":
    unittest.main()
