# Simple Fishing

A customizable fishing module for **Foundry VTT 14** and **D&D 5e**.

Place Fishing Spot actor tokens, roll for a bite, and reel when the moving fish crosses the green zone. Characters use inventory bait and reusable Fishing Tackle. The GM chooses rewards and adjusts difficulty through module settings.

## Upload this repository to GitHub

1. Create a **public** GitHub repository named **simple-fishing**. Leave its README/license/gitignore options unchecked because these files are included.
2. Extract the repository ZIP on your computer.
3. Open the extracted folder. Show hidden files if necessary (**Ctrl+H on Linux**).
4. In GitHub, choose **uploading an existing file** or **Add file → Upload files**.
5. Drag the **contents** of the extracted folder into the upload page, including **.github**, **.gitignore**, and **.gitattributes**. Commit to **main**.
6. Confirm **module.json** and **README.md** appear at the repository root and **.github/workflows/release.yml** exists. Do not upload only the ZIP or put everything inside an extra parent folder.

The source does not require you to enter your GitHub username anywhere. The release workflow generates the correct URLs from your repository automatically.

## Publish the first installable release

1. Open your repository's **Actions** tab. Enable workflows if GitHub asks.
2. Select **Publish Foundry Release**.
3. Click **Run workflow**, choose **main**, and use tag **v1.5.0**.
4. Wait for the workflow to finish. It runs tests and publishes a release containing **module.json** and **simple-fishing.zip**.
5. Open the workflow run's summary to copy your **Foundry manifest URL**.

No personal access token or extra secret is needed. The workflow uses GitHub's repository token with permission to write release assets. Your account/organization must allow GitHub Actions and that permission.

The install link will have this form, using your actual username and repository name:

```text
https://github.com/YOUR-USERNAME/simple-fishing/releases/latest/download/module.json
```

Use that link in **Foundry Setup → Add-on Modules → Install Module → Manifest URL**. It starts working after the release assets are published. Do not use the source repository's module.json URL: release manifests contain the generated download links.

## Features

- Fish button under Token Controls to place a fishing spot.
- Simple spot setup: name, catches remaining, difficulty, bite DC and deletion when empty.
- Optional bait; Fishing Tackle required by default.
- D20 bite check before the catch minigame.
- Dexterity slows fish movement; Wisdom widens the green zone.
- Default green zones: Easy 30%, Medium 15%, Hard 6%.
- No bait adds +5 bite DC and makes the zone 35% narrower by default.
- Failed bite rolls deplete stock, natural 1 scares fish away, and natural 20 adds stock.
- Drag-and-drop Items/RollTables for rewards, automatically awarded to inventory.
- GM settings for difficulty, speed, bar sizes, stat effects, timers and critical rules.

See the [User Guide](docs/USER_GUIDE.md) for installation, settings, player steps and recovery instructions.

## Publish future versions

Update **version** in both **module.json** and **package.json**. Update **docs/RELEASE_NOTES.md**, commit the changes, and run **Publish Foundry Release** with the matching tag, for example **v1.5.1**.

Alternatively, pushing a tag such as `v1.5.1` triggers the workflow automatically. The build rejects tags that do not match the source version. Foundry's stable manifest link stays the same, while each release points to its own ZIP.

Difficulty adjustments do not need releases: change **Module Settings → Simple Fishing → Fishing Difficulty** and save.

## Local development

No npm dependencies are required. Use Node 22+ (CI uses Node 24) and Python 3.10+.

```bash
npm test
python3 -m unittest discover -s tools -p 'test_*.py'
python3 tools/build_release.py --repository YOUR-USERNAME/simple-fishing --tag v1.5.0
```

The build creates **dist/module.json** and **dist/simple-fishing.zip**. The install ZIP contains only runtime assets, license and user documentation, with module.json at its root. It does not modify the source manifest or include development tools/workflows.

For a manual install, create **Data/modules/simple-fishing/** and extract the built **simple-fishing.zip** into that folder.

## Compatibility and validation

Targets Foundry 14's documented APIs and the dnd5e system. Automated tests use mocked Foundry objects and verify release packaging. This module has not been validated inside a licensed Foundry instance or with real multiplayer clients. Later Foundry major versions are allowed by the manifest but are not guaranteed compatible.

## License

[MIT](LICENSE). Copyright 2026 Bo Anderson.
